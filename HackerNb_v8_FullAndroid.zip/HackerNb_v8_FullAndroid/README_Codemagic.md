HackerNb - minimal project for Codemagic build. Replace with full project for full features.
