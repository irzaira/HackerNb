HackerNb v8 - Full Android project ready for Codemagic build.
See README_Codemagic.md for build instructions.
